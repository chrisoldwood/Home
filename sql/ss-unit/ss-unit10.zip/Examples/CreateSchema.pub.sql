/**
 * \file
 * \brief  Creates the schema for the Examples public API.
 * \author Chris Oldwood
 */

create schema pub;
go
