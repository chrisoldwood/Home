/**
 * \file
 * \brief  Creates the schemas for the unit tests.
 * \author Chris Oldwood
 */

create schema test;
go

create schema unit_test;
go
