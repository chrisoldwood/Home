/**
 * \file   CreateSchema.ssunit.sql
 * \brief  Creates the schema for the unit test framework.
 * \author Chris Oldwood
 */

create schema ssunit;
go
