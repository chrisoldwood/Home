SS-Unit v0.9
============


1: Installation
---------------

None required, this archive contains only source files. You do need to have
SQLCMD on your path to run the framework tests suite and examples.


2: Help/Manual
--------------

There is a HelpFile folder with an HTML based manual in it.


3: Contact Details
------------------

Email: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

10th November 2011
