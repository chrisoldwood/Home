WCL - Windows C++ Library
=========================

This is the core class library used by all my 16-bit applications.


EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

29th January 2004
