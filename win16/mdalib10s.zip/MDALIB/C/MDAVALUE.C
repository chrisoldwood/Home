/*****************************************************************************
** (C) Chris Wood 1995.
**
** MDAVALUE.C - MDA Library value conversion and drawing functions.
**
******************************************************************************
*/

#include <windows.h>
//#include "mdalib.h"

/**** Defines & Global variables. *******************************************/
extern LPSTR lpMDA;                /* Full address of start of MDA. */
extern BOOL  bOn;                  /* Display output on/off. */

/*****************************************************************************
*/
