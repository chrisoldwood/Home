/******************************************************************************
** (C) Chris Wood 1998
**
** MODULE:		TABPAGE.CPP
** COMPONENT:	Windows C++ Library.
** DESCRIPTION:	CTabPage class definition.
**
*******************************************************************************
*/

#include "wcl.hpp"

/******************************************************************************
** Method:		Constructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CTabPage::CTabPage(void)
{
}

/******************************************************************************
** Method:		Deconstructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CTabPage::~CTabPage(void)
{
}
