/******************************************************************************
** (C) Chris Wood 1998
**
** MODULE:		RTFFILE.CPP
** COMPONENT:	The Application.
** DESCRIPTION:	CRTFFile class definition.
**
*******************************************************************************
*/

#include "apphdrs.hpp"

/******************************************************************************
** Method:		Constructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CRTFFile::CRTFFile(void)
{
}

/******************************************************************************
** Method:		Deconstructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CRTFFile::~CRTFFile(void)
{
}
