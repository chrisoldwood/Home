/******************************************************************************
** (C) Chris Wood 1998
**
** MODULE:		BATFILE.CPP
** COMPONENT:	The Application.
** DESCRIPTION:	CBATFile class definition.
**
*******************************************************************************
*/

#include "apphdrs.hpp"

/******************************************************************************
** Method:		Constructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CBATFile::CBATFile(void)
{
}

/******************************************************************************
** Method:		Deconstructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CBATFile::~CBATFile(void)
{
}
