/******************************************************************************
** (C) Chris Wood 1998
**
** MODULE:		HPJFILE.CPP
** COMPONENT:	The Application.
** DESCRIPTION:	CHPJFile class definition.
**
*******************************************************************************
*/

#include "apphdrs.hpp"

/******************************************************************************
** Method:		Constructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CHPJFile::CHPJFile(void)
{
}

/******************************************************************************
** Method:		Deconstructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CHPJFile::~CHPJFile(void)
{
}
