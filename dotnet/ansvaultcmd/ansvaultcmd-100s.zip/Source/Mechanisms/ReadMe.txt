Mechanisms
==========

Introduction
------------

This is a C# library of reusable classes.

Contact Details
---------------

Email: gort@cix.co.uk
Web:   http://www.chrisoldwood.com

Chris Oldwood
3rd April 2017
