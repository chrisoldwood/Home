﻿using System;

namespace Mechanisms.Tests
{
    [AttributeUsage(AttributeTargets.Method)]
    public class TestCasesAttribute : Attribute
    {
    }
}
