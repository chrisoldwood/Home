﻿namespace Mechanisms.Host
{
    public static class ExitCode
    {
        public const int Success = 0;
        public const int Failure = 1;
        public const int UsageError = 2;
    }
}
