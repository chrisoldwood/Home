UT Server Browser v1.0 Alpha
============================

1) Installation.

Copy the files UTSvrBrowser.exe, UTSBMods.ini and UTSvrBrowser.ini to a folder.


2) Uninstallation.

Delete all files.


3) Manual/Help/Contact Info etc.

There is no manual at present.

EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

19th June 2003
