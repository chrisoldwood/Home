NetDDE v1.0
===========

1) Installation.

Copy the file NetDDEClient.exe to a folder on the DDE client machine.
Copy the file NetDDEServer.exe to a folder on the DDE server machine.

Configure the NetDDEClient to point to the NetDDEServer machine.


2) Uninstallation.

Delete the files NetDDE*.*


3) Manual/Help/Contact Info etc.

There is no manual at present.

There is a limitation that the Client and Server only support a single
topic for each DDE service.

EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

4th March 2003
