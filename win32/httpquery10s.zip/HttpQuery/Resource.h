//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by App.rc
//
#define IDR_APPICON                     2
#define IDR_APPMENU                     3
#define IDR_APPACCEL                    4
#define IDR_APPTOOLBAR                  5
#define ID_SERVER_POPUP                 100
#define ID_SERVER_CONNECT               101
#define ID_SERVER_DISCONNECT            102
#define ID_SERVER_EXIT                  109
#define ID_REQUEST_POPUP                200
#define ID_REQUEST_SEND                 209
#define ID_RESPONSE_POPUP               300
#define ID_RESPONSE_SAVE_AS             301
#define ID_WINDOW_POPUP                 800
#define ID_WINDOW_REQUEST               801
#define ID_WINDOW_RESPONSE              802
#define ID_WINDOW_NEXT                  808
#define ID_WINDOW_PREV                  809
#define ID_HELP_POPUP                   900
#define ID_HELP_CONTENTS                901
#define ID_HELP_ABOUT                   902
#define IDC_WEBSITE                     1083
#define IDC_EMAIL                       1084
#define IDC_VERSION                     1085
#define IDC_REQUEST_HEADERS             1086
#define IDC_REQUEST_CONTENT             1087
#define IDC_RESPONSE_HEADERS            1088
#define IDC_RESPONSE_CONTENT            1089
#define IDC_REQUEST_HEADERS_LABEL       1090
#define IDC_REQUEST_CONTENT_LABEL       1091
#define IDC_RESPONSE_HEADERS_LABEL      1092
#define IDC_RESPONSE_CONTENT_LABEL      1093
#define IDC_REQUEST_VERB                1095
#define IDC_REQUEST_URL                 1096
#define IDC_REQUEST_FORMAT              1097
#define IDC_TAB                         1098
#define IDC_HOST                        1099
#define IDC_PORT                        1100
#define IDD_MAIN                        5000
#define IDD_ABOUT                       5001
#define IDD_REQUEST                     5002
#define IDD_RESPONSE                    5003
#define IDD_CONNECT                     5004
#define ID_RES                          61745
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         169
#define _APS_NEXT_CONTROL_VALUE         1101
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
