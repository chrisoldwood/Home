PQT v1.0
========

1) Installation.

Copy the file PQT.exe to a folder.


2) Uninstallation.

Delete the files PQT.exe and PQT.ini.


3) Manual/Help/Contact Info etc.

There is no manual at present.

EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

13th January 2003
