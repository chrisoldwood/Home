select * from publishers
