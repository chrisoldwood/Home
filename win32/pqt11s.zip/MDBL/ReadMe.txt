MDBL - Memory DataBase Library
==============================

This library provides classes to create an in-memory database which can be
standalone or act as a cache for data retrieved from a real ODBC data source.


EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

19th June 2003
