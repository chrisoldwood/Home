UT Cache Manager v2.0
=====================

1) Installation.

Copy the files UTCacheMgr.exe and UTCacheMgr.hlp to a folder.


2) Uninstallation.

Delete the files UTCacheMgr.exe, UTCacheMgr.hlp, UTCacheMgr.log and UTCacheMgr.ini.


3) Manual/Help/Contact Info etc.

Its all in the HelpFile - UTCacheMgr.hlp.

EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 
(gort@cix.co.uk)

19th June 2003
