TaskTracker v4.0
================


1: Installation
---------------

Run setup.exe.

or

Copy the files TaskTrak.* to a folder.


2: Uninstallation
-----------------

Delete the files TaskTrak.*.


3: Help/Manual
--------------

There is a HelpFile - TaskTrak.mht.


4: Contact Details
------------------

Email: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

26th March 2007
