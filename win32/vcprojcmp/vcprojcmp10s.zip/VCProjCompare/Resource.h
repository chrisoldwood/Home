//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by App.rc
//
#define IDR_APPICON                     2
#define IDR_APPMENU                     3
#define IDC_NONE                        3
#define IDR_APPACCEL                    4
#define IDR_APPTOOLBAR                  5
#define IDB_RESICONS                    7
#define IDR_CONTEXT                     50
#define IDD_PROGRESS                    51
#define IDD_FILELIST                    52
#define IDD_OPTIONS                     53
#define ID_FILE_POPUP                   100
#define ID_FILE_LIST                    101
#define ID_FILE_COMPARE                 102
#define ID_FILE_REFRESH                 103
#define ID_FILE_EXIT                    109
#define ID_CONTEXT_PROJECT              173
#define ID_CONTEXT_BUILD                201
#define ID_TOOLS_POPUP                  800
#define ID_TOOLS_OPTIONS                801
#define ID_HELP_POPUP                   900
#define ID_HELP_CONTENTS                901
#define ID_HELP_ABOUT                   902
#define IDC_WEBSITE                     1083
#define IDC_EMAIL                       1084
#define IDC_VERSION                     1085
#define IDC_COPYRIGHT                   1086
#define IDC_RESULTS                     1086
#define IDC_FOLDER                      1087
#define IDC_FILES                       1088
#define IDC_PATH_1                      1089
#define IDC_PATH_2                      1090
#define IDC_LABEL_1                     1091
#define IDC_LABEL_2                     1092
#define IDC_BROWSE_1                    1093
#define IDC_BROWSE_2                    1094
#define IDC_PROGRESS                    1096
#define IDC_STATUS                      1097
#define IDC_SETTINGS                    1099
#define IDC_PROJECT                     1100
#define IDC_BUILD                       1101
#define IDC_REMOVE                      1102
#define IDC_HEADING                     1103
#define IDD_MAIN                        5000
#define IDD_ABOUT                       5001
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         174
#define _APS_NEXT_CONTROL_VALUE         1104
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
