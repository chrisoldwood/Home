VC++ Project Compare v1.0
=========================


1: Installation
---------------

Run setup.exe.

or

Copy the files VCProjCompare.* to a folder.


2: Uninstallation
-----------------

Delete the files listed above.


3: Help/Manual
--------------

There is a HelpFile - VCProjCompare.mht.


4: Contact Details
------------------

Email: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

8th June 2009
