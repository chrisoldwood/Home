////////////////////////////////////////////////////////////////////////////////
//! \file   StringUtils.hpp
//! \brief  Utility functions for formatting strings.
//! \author Chris Oldwood

// Check for previous inclusion
#ifndef CORE_STRINGUTILS_HPP
#define CORE_STRINGUTILS_HPP

#if _MSC_VER > 1000
#pragma once
#endif

#include <stdarg.h>

namespace Core
{

////////////////////////////////////////////////////////////////////////////////
// Format the string ala printf.

tstring FmtEx(const tchar* pszFormat, va_list args);

////////////////////////////////////////////////////////////////////////////////
// Format the string ala printf.

tstring Fmt(const tchar* pszFormat, ...);

////////////////////////////////////////////////////////////////////////////////
//! Skip any leading whitespace.

template<typename First, typename Last>
First skipWhitespace(First first, Last last)
{
	while ( (first != last) && ((*first == TXT(' ')) || (*first == TXT('\t')) || (*first == TXT('\r')) || (*first == TXT('\n'))) )
		++first;

	return first;
}

////////////////////////////////////////////////////////////////////////////////
//! Format a value into a string.

template<typename T>
tstring format(const T& value);

////////////////////////////////////////////////////////////////////////////////
// Format a boolean value into a string.

template<>
tstring format(const bool& value);

////////////////////////////////////////////////////////////////////////////////
// Format a signed integer value into a string.

template<>
tstring format(const int& value);

////////////////////////////////////////////////////////////////////////////////
// Format an unsigned integer value into a string.

template<>
tstring format(const uint& value);

////////////////////////////////////////////////////////////////////////////////
// Format a 64-bit unsigned integer value into a string.

template<>
tstring format(const uint64& value);

////////////////////////////////////////////////////////////////////////////////
//! Parse a value from a string.

template<typename T>
T parse(const tstring& buffer); // throw(ParseException)

////////////////////////////////////////////////////////////////////////////////
// Parse a boolean value from a string.

template<>
bool parse(const tstring& buffer); // throw(ParseException)

////////////////////////////////////////////////////////////////////////////////
// Parse a signed integer value from a string.

template<>
int parse(const tstring& buffer); // throw(ParseException)

////////////////////////////////////////////////////////////////////////////////
// Parse an unsigned integer value from a string.

template<>
uint parse(const tstring& buffer); // throw(ParseException)

////////////////////////////////////////////////////////////////////////////////
// Parse a 64-bit unsigned integer value from a string.

template<>
uint64 parse(const tstring& buffer); // throw(ParseException)

////////////////////////////////////////////////////////////////////////////////
// Convert a string to upper case.

void makeUpper(tstring& string);

////////////////////////////////////////////////////////////////////////////////
// Create an upper case version of a string.

tstring createUpper(const tstring& string);

////////////////////////////////////////////////////////////////////////////////
// Convert a string to lower case.

void makeLower(tstring& string);

////////////////////////////////////////////////////////////////////////////////
// Create a lower case version of a string.

tstring createLower(const tstring& string);

//namespace Core
}

#endif // CORE_STRINGUTILS_HPP
