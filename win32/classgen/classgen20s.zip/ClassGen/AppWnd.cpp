////////////////////////////////////////////////////////////////////////////////
//! \file   AppWnd.cpp
//! \brief  The AppWnd class definition.
//! \author Chris Oldwood

#include "Common.hpp"
#include "AppWnd.hpp"

////////////////////////////////////////////////////////////////////////////////
//! Default constructor.

AppWnd::AppWnd()
	: CDlgFrame(IDR_APPICON, m_appDlg, true)
{
}

////////////////////////////////////////////////////////////////////////////////
//! Destructor.

AppWnd::~AppWnd()
{
}

////////////////////////////////////////////////////////////////////////////////
//! Handle window creation.

void AppWnd::OnCreate(const CRect& clientRect)
{
	//
	// Create and attach the components.
	//
	m_appDlg.RunModeless(*this);
	ActiveDlg(&m_appDlg);

	// Call base class.
	CDlgFrame::OnCreate(clientRect);
}
