Class Generator v1.1
====================

1) Installation.

Copy the file ClassGen.exe, ClassGen.ini and *.?$$ to a folder.


2) Uninstallation.

Delete all files.


3) Manual/Help/Contact Info etc.

There is no manual at present.

EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 
(gort@cix.co.uk)

19th June 2003
