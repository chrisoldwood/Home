Setup v1.0
==========

1) Manual.

Setup.exe requires a config file called setup.ini, which must live in the same
folder as the executable. An example one is provided, which has comments to
tell you what to set.

It has no Uninstall support at present.


2) Help/Contact Info etc.

EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 
(gort@cix.co.uk)

29th January 2004
