Core Library
============

Introduction
------------

This C++ library underpins all my applications and is intended to contain all
the platform agnostic code.

Documentation
-------------

See http://www.chrisoldwood.com/win32/dox/core/index.html.

Development
-----------

See DevNotes.txt

Contact Details
---------------

Email: gort@cix.co.uk
Web:   http://www.chrisoldwood.com

Chris Oldwood
22nd October 2013
