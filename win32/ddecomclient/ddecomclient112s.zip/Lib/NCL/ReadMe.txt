NCL (Network & Comms) Library
=============================

Introduction
------------

This C++ class library provides support for IPC over DDE, Named Pipes and
Sockets.

Documentation
-------------

See http://www.chrisoldwood.com/win32/dox/ncl/index.html.

Development
-----------

See DevNotes.txt

Contact Details
---------------

Email: gort@cix.co.uk
Web:   http://www.chrisoldwood.com

Chris Oldwood
22nd October 2013
