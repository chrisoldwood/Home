COM Library
===========

Introduction
------------

This C++ class library provides support for creating in-process COM servers.

Documentation
-------------

See http://www.chrisoldwood.com/win32/dox/com/index.html.

Development
-----------

See DevNotes.txt

Contact Details
---------------

Email: gort@cix.co.uk
Web:   http://www.chrisoldwood.com

Chris Oldwood
22nd October 2013
