DDE COM Client v1.0
===================


1: Installation
---------------

Copy the files DDECOMClient.* to a folder.
Register the component using "regsvr32.exe DDECOMClient.dll"


2: Uninstallation
-----------------

Unregister the component using "regsvr32.exe /u DDECOMClient.dll"
Delete the files DDECOMClient.*.


3: Help/Manual
--------------

There is a HelpFile - DDECOMClient.html.


4: Contact Details
------------------

Email: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

19th July 2007
