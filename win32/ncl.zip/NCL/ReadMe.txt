NCL - Network & Comms Library
=============================

This library provides classes for IPC over DDE, Named Pipes and Sockets.


EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

19th June 2003
