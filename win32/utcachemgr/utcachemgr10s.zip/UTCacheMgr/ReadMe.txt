UT Cache Manager v1.0
=====================

1) Installation.

Copy the files UTCacheMgr.exe and UTCacheMgr.hlp to a folder.


2) Uninstallation.

Delete the files UTCacheMgr.exe, UTCacheMgr.hlp, UTCacheMgr.log and UTCacheMgr.ini.


3) Manual/Help/Contact Info etc.

Its all in the HelpFile - UTCacheMgr.hlp.


Chris Oldwood 
(gort@cix.co.uk)

1st August 2002
