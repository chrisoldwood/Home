UT Cache Manager v2.5
=====================

1) Installation.

Run setup.exe.


2) Uninstallation.

Delete the files UTCacheMgr.*.


3) Manual/Help etc.

Its all in the HelpFile - UTCacheMgr.hlp.


4) Contact Details.

EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

31st March 2004
