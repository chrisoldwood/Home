/******************************************************************************
** (C) Chris Oldwood
**
** MODULE:		STREAMEXCEPTION.CPP
** COMPONENT:	Windows C++ Library.
** DESCRIPTION:	CStreamException class definition.
**
*******************************************************************************
*/

#include "wcl.hpp"

/******************************************************************************
** Method:		Constructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CStreamException::CStreamException()
{
}

/******************************************************************************
** Method:		Destructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CStreamException::~CStreamException()
{
}
