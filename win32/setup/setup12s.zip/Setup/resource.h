//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Setup.rc
//
#define IDR_APPICON                     2
#define IDR_APPMENU                     3
#define IDR_APPACCEL                    4
#define IDYESALL                        8
#define IDNOALL                         9
#define ID_FILE_EXIT                    109
#define ID_HELP_POPUP                   900
#define ID_HELP_CONTENTS                901
#define ID_HELP_ABOUT                   902
#define IDC_PROGRESS                    1080
#define IDC_OPERATION                   1081
#define IDC_WEBSITE                     1083
#define IDC_EMAIL                       1084
#define IDC_VERSION                     1085
#define IDC_INSTALL                     1087
#define IDC_CANCEL                      1088
#define IDC_ABOUT                       1089
#define IDC_FOLDER                      1090
#define IDC_BROWSE                      1091
#define IDC_DESK_ICON                   1092
#define IDC_PROG_ICON                   1093
#define IDC_CREATE                      1094
#define IDC_EXISTING                    1095
#define IDC_NEW_GROUP                   1096
#define IDC_OLD_GROUP                   1097
#define IDC_ALL_USERS                   1100
#define IDC_FILENAME_1                  1101
#define IDC_FILEINFO_1                  1102
#define IDC_FILENAME_2                  1103
#define IDC_FILEINFO_2                  1104
#define IDD_MAIN                        5000
#define IDD_ABOUT                       5001
#define IDD_PROGRESS                    5007
#define IDD_CONFLICT                    5012
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         163
#define _APS_NEXT_CONTROL_VALUE         1101
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
