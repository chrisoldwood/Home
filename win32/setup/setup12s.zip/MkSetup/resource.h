//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MkSetup.rc
//
#define IDR_APPICON                     2
#define IDR_APPMENU                     3
#define IDR_APPACCEL                    4
#define IDR_APPTOOLBAR                  5
#define ID_FILE_POPUP                   100
#define ID_FILE_NEW                     101
#define ID_FILE_OPEN                    102
#define ID_FILE_SAVE                    103
#define ID_FILE_SAVEAS                  104
#define ID_FILE_CLOSE                   105
#define ID_FILE_MRU_1                   106
#define ID_FILE_MRU_2                   107
#define ID_FILE_MRU_3                   108
#define ID_FILE_MRU_4                   109
#define ID_FILE_MRU_5                   110
#define ID_FILE_MRU_6                   111
#define ID_FILE_MRU_7                   112
#define ID_FILE_MRU_8                   113
#define ID_FILE_MRU_9                   114
#define ID_FILE_EXIT                    115
#define IDD_PROJ_CFG                    131
#define IDD_FILE_PROPS                  132
#define ID_EDIT_POPUP                   200
#define ID_EDIT_ADD                     201
#define ID_EDIT_ADD_MANY                202
#define ID_EDIT_PROPS                   203
#define ID_EDIT_REMOVE                  204
#define ID_EDIT_PROJ_CFG                209
#define ID_HELP_POPUP                   900
#define ID_HELP_CONTENTS                901
#define ID_HELP_ABOUT                   902
#define IDC_GRID                        1060
#define IDC_WEBSITE                     1083
#define IDC_EMAIL                       1084
#define IDC_VERSION                     1085
#define IDC_TITLE                       1086
#define IDC_PRODUCT                     1087
#define IDC_FOLDER                      1088
#define IDC_PROG_ICON                   1089
#define IDC_ALL_USERS                   1090
#define IDC_NEW_GROUP                   1091
#define IDC_GROUP                       1092
#define IDC_DESK_ICON                   1093
#define IDC_FILE_NAME                   1094
#define IDC_AUTHOR                      1094
#define IDC_ICON_NAME                   1097
#define IDC_ICON_DESC                   1098
#define IDC_COMBO1                      1099
#define IDC_ROOT                        1099
#define IDD_MAIN                        5000
#define IDD_ABOUT                       5001
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         168
#define _APS_NEXT_CONTROL_VALUE         1100
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
