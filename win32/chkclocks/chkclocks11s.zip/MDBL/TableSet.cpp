/******************************************************************************
**
** MODULE:		TABLESET.CPP
** COMPONENT:	Memory Database Library.
** DESCRIPTION:	CTableSet class definition.
**
*******************************************************************************
*/

#include "MDBL.hpp"

/******************************************************************************
** Method:		Constructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CTableSet::CTableSet()
{
}

/******************************************************************************
** Method:		Destructor.
**
** Description:	.
**
** Parameters:	None.
**
** Returns:		Nothing.
**
*******************************************************************************
*/

CTableSet::~CTableSet()
{
}
