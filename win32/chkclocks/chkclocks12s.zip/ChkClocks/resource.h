//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ChkClocks.rc
//
#define IDR_APPICON                     2
#define IDR_APPMENU                     3
#define IDR_APPACCEL                    4
#define IDR_APPTOOLBAR                  5
#define IDR_CONTEXT                     6
#define ID_FILE_POPUP                   100
#define ID_FILE_CHECK                   101
#define ID_FILE_EXIT                    109
#define ID_EXCLUDE_COMPUTER             172
#define ID_EXCLUDE_DOMAIN               173
#define ID_REPORT_POPUP                 200
#define ID_REPORT_CLIPBOARD             201
#define ID_REPORT_FILE                  202
#define ID_REPORT_PRINT                 203
#define ID_OPTIONS_POPUP                800
#define ID_OPTIONS_SCANNING             801
#define ID_OPTIONS_REPORTING            802
#define ID_HELP_POPUP                   900
#define ID_HELP_CONTENTS                901
#define ID_HELP_ABOUT                   902
#define IDC_GRID                        1060
#define IDC_PROGRESS                    1080
#define IDC_OPERATION                   1081
#define IDC_WEBSITE                     1083
#define IDC_EMAIL                       1084
#define IDC_VERSION                     1085
#define IDC_INCLUDE                     1087
#define IDC_EXCLUDE                     1088
#define IDC_INC_ADD                     1089
#define IDC_INC_REMOVE                  1090
#define IDC_NAME                        1090
#define IDC_EXC_ADD                     1091
#define IDC_ABORT                       1091
#define IDC_EXC_REMOVE                  1092
#define IDC_FMT_FIXED                   1093
#define IDC_FMT_VARIABLE                1094
#define IDC_TOLERANCE                   1095
#define IDC_THREADS                     1096
#define IDC_CORRECT                     1097
#define IDC_FAILED                      1098
#define IDC_CHECK1                      1098
#define IDC_AUTO_EXCLUDE                1098
#define IDD_MAIN                        5000
#define IDD_ABOUT                       5001
#define IDD_PROGRESS                    5003
#define IDD_OPTS_SCAN                   5004
#define IDD_OPTS_REPORT                 5005
#define IDD_INCEXC_NAME                 5006
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         174
#define _APS_NEXT_CONTROL_VALUE         1099
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
