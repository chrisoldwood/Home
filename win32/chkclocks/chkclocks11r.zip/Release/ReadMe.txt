Check Clocks v1.1
=================

1) Installation.

Copy the file ChkClocks.exe to a folder.


2) Uninstallation.

Delete the files ChkClocks.exe and ChkClocks.ini.


3) Manual/Help/Contact Info etc.

There is no manual at present.

EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 
(gort@cix.co.uk)

19th June 2003
