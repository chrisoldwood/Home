vdproj2wix v1.0
===============


1: Installation
---------------

None required.


2: Help/Manual
--------------

There is a HelpFile - vdproj2wix.html.


3: Contact Details
------------------

Email: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

31st October 2011
