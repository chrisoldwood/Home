vdproj2wix v0.1 [Alpha]
=======================


1: Installation
---------------

Copy the vdproj2wix.ps1 to a suitable location.


2: Help/Manual
--------------

There is a HelpFile - vdproj2wix.mht.


3: Contact Details
------------------

Email: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

24th June 2011
