vdproj2wix v0.9
===============


1: Installation
---------------

Copy the file vdproj2wix.ps1 to a suitable location.


2: Help/Manual
--------------

There is a HelpFile - vdproj2wix.html.


3: Contact Details
------------------

Email: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

25th October 2011
