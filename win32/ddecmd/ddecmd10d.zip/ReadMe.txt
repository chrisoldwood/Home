DDE Command v1.0
================


1: Installation
---------------

Run setup.exe.

or

Copy the files DDECmd.* to a folder.


2: Uninstallation
-----------------

Delete the files listed above.


3: Help/Manual
--------------

There is a HelpFile - DDECmd.mht.


4: Contact Details
------------------

Email: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

15th December 2008
