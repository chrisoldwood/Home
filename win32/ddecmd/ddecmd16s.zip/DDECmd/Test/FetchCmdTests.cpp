////////////////////////////////////////////////////////////////////////////////
//! \file   FetchCmdTests.cpp
//! \brief  The unit tests for the FetchCmd class.
//! \author Chris Oldwood

#include "Common.hpp"
#include <Core/UnitTest.hpp>

TEST_SET(FetchCmd)
{
/*
TEST_CASE("")
{
	TEST_TRUE();
}
TEST_CASE_END
*/
}
TEST_SET_END
