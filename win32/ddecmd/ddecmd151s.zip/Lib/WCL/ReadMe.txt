WCL (Windows C++) Library
=========================

Introduction
------------

This C++ class library provides the core support for the Windows platform.
Historically it also used to be the base class library too, but I've tried to
push as much of the platform agnostic code down into the Core library.

Documentation
-------------

See http://www.chrisoldwood.com/win32/dox/wcl/index.html.

Development
-----------

See DevNotes.txt

Contact Details
---------------

Email: gort@cix.co.uk
Web:   http://www.chrisoldwood.com

Chris Oldwood
22nd October 2013
