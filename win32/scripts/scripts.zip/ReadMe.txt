Scripts
=======

Introduction
------------

These are the build scripts I use compile the code with both Visual C++ and
GCC, via Code::Blocks. It also contains various other scripts to run the tests,
configure STLport, upgrade projects to newer VC++ versions, etc.

Releases
--------

Stable releases are formally packaged and made available from my Win32 tools page:
http://www.chrisoldwood.com/win32.htm

The latest code is available from my GitHub repo:
https://github.com/chrisoldwood/Scripts

Contact Details
---------------

Email: gort@cix.co.uk
Web:   http://www.chrisoldwood.com

Chris Oldwood
22nd October 2013
