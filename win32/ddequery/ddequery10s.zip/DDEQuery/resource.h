//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DDEQuery.rc
//
#define IDR_APPICON                     2
#define IDR_APPMENU                     3
#define IDR_APPACCEL                    4
#define IDR_APPTOOLBAR                  5
#define ID_SERVER_POPUP                 100
#define ID_SERVER_CONNECT               101
#define ID_SERVER_DISCONNECT            102
#define ID_SERVER_MRU_1                 103
#define ID_SERVER_MRU_2                 104
#define ID_SERVER_MRU_3                 105
#define ID_SERVER_MRU_4                 106
#define ID_SERVER_MRU_5                 107
#define ID_SERVER_EXIT                  109
#define ID_COMMAND_POPUP                200
#define ID_COMMAND_REQUEST              201
#define ID_COMMAND_POKE                 202
#define ID_COMMAND_EXECUTE              203
#define ID_LINK_POPUP                   300
#define ID_LINK_ADVISE                  301
#define ID_LINK_UNADVISE                302
#define ID_LINK_FILE                    305
#define ID_HELP_POPUP                   900
#define ID_HELP_CONTENTS                901
#define ID_HELP_ABOUT                   902
#define IDC_WEBSITE                     1083
#define IDC_EMAIL                       1084
#define IDC_VERSION                     1085
#define IDC_SERVICE                     1086
#define IDC_TOPIC                       1087
#define IDC_ITEM                        1087
#define IDC_LINKS                       1088
#define IDC_LINKS_LABEL                 1089
#define IDC_ITEM_LABEL                  1090
#define IDC_VALUE                       1091
#define IDC_COMBO1                      1093
#define IDC_FORMAT                      1093
#define IDD_MAIN                        5000
#define IDD_ABOUT                       5001
#define IDD_CONNECT                     5002
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         181
#define _APS_NEXT_CONTROL_VALUE         1094
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
