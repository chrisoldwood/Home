WCL - Windows C++ Library
=========================

This is the core class library used by all my applications.


EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

19th June 2003
