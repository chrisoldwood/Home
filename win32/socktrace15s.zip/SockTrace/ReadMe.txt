Socket Trace v1.5
=================

1) Installation.

Run Setup.exe or copy the file SockTrace.exe to a folder.


2) Uninstallation.

Delete the files SockTrace.*, RelNotes.txt and ReadMe.txt.


3) Manual/Help/Contact Info etc.

There is no manual at present.

EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

6th July 2004
