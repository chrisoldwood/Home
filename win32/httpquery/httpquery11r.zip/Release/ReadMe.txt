HttpQuery v1.1
==============

1) Installation.

Copy the file HttpQuery.exe to a folder.


2) Uninstallation.

Delete the files HttpQuery.exe and HttpQuery.ini.


3) Manual/Help/Contact Info etc.

There is no manual at present.

EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

19th June 2003
