XML Editor v0.5
===============


1: Installation
---------------

Run setup.exe.

or

Copy the files XMLEdit.* to a folder.


2: Uninstallation
-----------------

Delete the files listed above.


3: Help/Manual
--------------

There is no HelpFile at present.


4: Contact Details
------------------

Email: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

29th September 2008
