WMI Command v1.1
================


1: Installation/Removal
-----------------------

The release comes as a standard MSI package. 


2: Help/Manual
--------------

There is a HelpFile - WMICmd.html.


3: Contact Details
------------------

Email: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

25th June 2012
