WMI Command v1.0 [Beta]
=======================


1: Installation
---------------

Run setup.exe.

or

Copy the files WMICmd.* to a folder.


2: Uninstallation
-----------------

Delete the files listed above.


3: Help/Manual
--------------

There is a HelpFile - WMICmd.mht.


4: Contact Details
------------------

Email: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

11th October 2010
