////////////////////////////////////////////////////////////////////////////////
//! \file   TestWriter.cpp
//! \brief  The unit tests for the Writer class.
//! \author Chris Oldwood

#include "stdafx.h"
#include <Core/UnitTest.hpp>
#include <XML/Writer.hpp>

////////////////////////////////////////////////////////////////////////////////
//! The unit tests for the Writer class.

void TestWriter()
{
}
