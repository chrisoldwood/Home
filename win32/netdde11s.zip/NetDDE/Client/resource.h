//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by App.rc
//
#define IDR_APPICON                     2
#define IDR_APPMENU                     3
#define IDR_APPACCEL                    4
#define IDR_APPTOOLBAR                  5
#define IDI_NET_IDLE                    10
#define IDI_NET_LOST                    11
#define IDI_NET_SEND                    12
#define IDI_NET_RECV                    13
#define IDI_NET_BOTH                    14
#define ID_FILE_POPUP                   100
#define ID_FILE_EXIT                    109
#define ID_VIEW_POPUP                   200
#define ID_VIEW_SERVER_CONNS            201
#define ID_VIEW_DDE_CONVS               202
#define ID_OPTIONS_POPUP                300
#define ID_OPTIONS_GENERAL              301
#define ID_OPTIONS_TRACE                302
#define ID_OPTIONS_SERVICES             303
#define ID_HELP_POPUP                   900
#define ID_HELP_CONTENTS                901
#define ID_HELP_ABOUT                   902
#define IDC_GRID                        1060
#define IDC_WEBSITE                     1083
#define IDC_EMAIL                       1084
#define IDC_VERSION                     1085
#define IDC_TRACE                       1086
#define IDC_CONVERSATIONS               1086
#define IDC_ADVISES                     1087
#define IDC_UPDATES                     1088
#define IDC_REQUESTS                    1089
#define IDC_WINDOW                      1094
#define IDC_FILE                        1095
#define IDC_CONNECTIONS                 1096
#define IDC_MAX_LINES                   1097
#define IDC_FILE_NAME                   1098
#define IDC_MIN_TO_TRAY                 1101
#define IDC_TRAY_ICON                   1102
#define IDC_SERVICES                    1102
#define IDC_ADD                         1103
#define IDC_EDIT                        1104
#define IDC_SERVICE                     1104
#define IDC_REMOVE                      1105
#define IDC_SERVER                      1105
#define IDC_PIPE                        1106
#define IDC_ASYNC_ADVISES               1107
#define IDC_ASYNC                       1107
#define IDD_SERVICE                     2037
#define ID_VIEW_CLEAR_TRACE             3068
#define IDD_MAIN                        5000
#define IDD_ABOUT                       5001
#define IDD_TRACE_OPTIONS               5002
#define IDD_SERVER_CONNS                5003
#define IDD_DDE_CONVS                   5004
#define IDD_OPTIONS                     5005
#define IDD_SERVICES                    5006
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        2038
#define _APS_NEXT_COMMAND_VALUE         3069
#define _APS_NEXT_CONTROL_VALUE         1108
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
