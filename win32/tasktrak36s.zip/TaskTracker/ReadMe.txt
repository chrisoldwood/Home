TaskTracker v3.6
================

1) Installation.

Copy the file TaskTrak.exe to a folder.


2) Uninstallation.

Delete the files TaskTrak.exe, TaskTrak.dat and TaskTrak.ini.


3) Manual/Help/Contact Info etc.

There is no manual at present.

EMail: gort@cix.co.uk
Web:   http://www.cix.co.uk/~gort


Chris Oldwood 

19th June 2003
